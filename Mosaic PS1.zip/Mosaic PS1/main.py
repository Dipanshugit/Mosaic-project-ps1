from cv2 import INTER_CUBIC
import torch
import numpy as np
import pandas as pd
import cv2
import matplotlib.pyplot as plt
import torch.nn as nn
from torch.utils.data import TensorDataset
from torch.utils.data import DataLoader
from torch.utils.data import random_split
import torch.nn.functional as F

# Read 'emonji.jpg'
image = cv2.imread('emonji.jpg')


# Defining Model
def accuracy(outputs, labels):
    _, preds = torch.max(outputs, dim=1)
    return torch.tensor(torch.sum(preds == labels).item() / len(preds))

class MnistModel(nn.Module):
    def __init__(self, in_size, hidden_size,hidden2_size,hidden3_size, out_size):
        super().__init__()
        self.linear1 = nn.Linear(in_size, hidden_size)
        self.linear2 = nn.Linear(hidden_size, hidden2_size)
        self.linear3 = nn.Linear(hidden2_size, hidden3_size)
        self.linear4 = nn.Linear(hidden3_size, out_size)
        
    def forward(self, xb):
        xb = xb.reshape(-1, 784)
        out = self.linear1(xb)
        out = F.relu(out)
        out = self.linear2(out)
        out = F.relu(out)

        out = self.linear3(out)
        out = F.relu(out)
        out = self.linear4(out)
        return out
    
    def training_step(self, batch):
        images, labels = batch 
        out = self(images)                  
        loss = F.cross_entropy(out, labels) 
        return loss
    
    def validation_step(self, batch):
        images, labels = batch 
        out = self(images)                    
        loss = F.cross_entropy(out, labels)  
        acc = accuracy(out, labels)          
        return {'val_loss': loss, 'val_acc': acc}
        
    def validation_epoch_end(self, outputs):
        batch_losses = [x['val_loss'] for x in outputs]
        epoch_loss = torch.stack(batch_losses).mean()   
        batch_accs = [x['val_acc'] for x in outputs]
        epoch_acc = torch.stack(batch_accs).mean()      
        return {'val_loss': epoch_loss.item(), 'val_acc': epoch_acc.item()}
    
    def epoch_end(self, epoch, result):
        print("Epoch [{}], val_loss: {:.4f}, val_acc: {:.4f}".format(epoch, result['val_loss'], result['val_acc']))


def evaluate(model, val_loader):
    outputs = [model.validation_step(batch) for batch in val_loader]
    return model.validation_epoch_end(outputs)

def fit(epochs, lr, model, train_loader, val_loader, opt_func=torch.optim.SGD):
    history = []
    optimizer = opt_func(model.parameters(), lr)
    for epoch in range(epochs):
        for batch in train_loader:
            loss = model.training_step(batch)
            loss.backward()
            optimizer.step()
            optimizer.zero_grad()
        result = evaluate(model, val_loader)
        model.epoch_end(epoch, result)
        history.append(result)
    return history

# Loading Model
model = torch.load('model.h5')

def predict_image(img, model):
    xb = img.unsqueeze(0)
    yb = model(xb)
    _, preds = torch.max(yb, dim=1)
    return preds[0].item()


# Processing 'emonji.jpg'
image = cv2.resize(image,(1000,500),interpolation=cv2.INTER_CUBIC)
original = image.copy()
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
blurred = cv2.GaussianBlur(gray, (3, 3), 0)
canny = cv2.Canny(blurred, 120, 255, 1)
kernel = np.ones((5,5),np.uint8)
kernel1 = np.ones((2,2),np.uint8)
dilate = cv2.dilate(canny, kernel, iterations=1)

cnts = cv2.findContours(dilate, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
cnts = cnts[0] if len(cnts) == 2 else cnts[1]

sorted_cnts = sorted(cnts, key=lambda ctr: cv2.boundingRect(ctr)[0])

image_number = 0
for c in sorted_cnts:
    x,y,w,h = cv2.boundingRect(c)
    if (h*w)<4000:
        continue
    elif (h*w)>4000:
        cv2.rectangle(image, (x-int(w/8), y-int(h/8)), (x + w+int(w/8), y + h+int(h/8)), (36,255,12), 2)
        ROI = original[y-int(h/8):y+h+int(h/8), x-int(w/8):x+w+int(w/8)]
        cv2.imwrite("ROI_{}.png".format(image_number), ROI)
        image_number += 1

def funarray2():
    a = []
    for i in range(image_number):
        img = cv2.imread("ROI_"+str(i)+".png", 0)
        img = cv2.resize(img,(28,28),interpolation=cv2.INTER_CUBIC)
        img = cv2.bitwise_not(img)
        ret , img = cv2.threshold(img,120,255,cv2.THRESH_TOZERO)
        img = cv2.dilate(img, kernel1, iterations=1)
        img=cv2.transpose(img)
                    
        img_ = img.flatten()
        a.append(img_)
    return a

x_train = funarray2()
x_train1 = np.array(x_train)

ts_in1=torch.tensor(x_train1)
ts_in1=ts_in1.float()

op=""
for i in range(image_number):
  img2 = ts_in1[i]
  img2 = img2.reshape(1,28,28)
  img3 = np.array(img2.reshape(28,28))
  prediction_=predict_image(img2, model)
  transdict = {0:'A',1:'B',2:'C',3:'E',4:'F',5:'G',6:'H',7:'K',8:'L',9:'M',10:'N',11:'P',12:'Q',13:'R',14:'S',15:'T',16:'W',17:'X',18:'Y',19:'Z',20:'1',21:'2',22:'3',23:'4',24:'5',25:'6',26:'7'}
  op+=(transdict[prediction_])
print(op)